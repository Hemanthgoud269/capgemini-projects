package com.capgemini.tcc.connection;
import java.sql.Connection;
import java.sql.DriverManager;
public class CommonConnection {
		public static Connection getcon() throws Exception  {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg611","training611");
			System.out.println("Connected");
			return c;
		}
	}


