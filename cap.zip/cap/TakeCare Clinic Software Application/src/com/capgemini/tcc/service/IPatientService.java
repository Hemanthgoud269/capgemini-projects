package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;

public interface IPatientService {
	int addPatientdetails(PatientBean patient);
	PatientBean getPatientDetails(int patientID);

}
