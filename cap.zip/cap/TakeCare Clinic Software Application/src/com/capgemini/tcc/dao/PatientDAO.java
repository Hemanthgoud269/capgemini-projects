package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.connection.CommonConnection;
        


public class PatientDAO implements IPatientDAO {
	private Connection cn;
	private PreparedStatement pst;
	public int addPatientdetails(PatientBean patient) {

    	try {
			cn=CommonConnection.getcon();
			 pst=cn.prepareStatement("Insert into patient values(Patient_id_Seq.nextval ,? ,? ,? ,? ,sysdate)");
			 pst.setString(1,patient.getPatientName());
			 pst.setInt(2,patient.getPatientAge());
			 pst.setLong(3,patient.getPatientPhoneNumber());
			 pst.setString(4,patient.getDescription());
			 pst.executeUpdate();
			 System.out.println("Patient Information stored successfully");				 
		} catch (Exception e) {
			
			e.printStackTrace();
		}
    	   
		return 0;}
	public PatientBean getPatientDetails(int patientID) {
		return null;}

}
