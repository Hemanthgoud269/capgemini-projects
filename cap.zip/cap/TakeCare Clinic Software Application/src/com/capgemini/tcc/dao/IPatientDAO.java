package com.capgemini.tcc.dao;

import com.capgemini.tcc.bean.PatientBean;

public interface IPatientDAO {
	int addPatientdetails(PatientBean patient);
	PatientBean getPatientDetails(int patientID);

}
