import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class check extends HttpServlet {
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException
			{
				/*Scanner s=new Scanner(System.in);
				System.out.println("Enter Book BooId");
					bookId = s.nextInt();
					System.out.println("Enter Book Titile");
					title = s.next();	
					System.out.println("Enter Book price");
					price = s.nextFloat();
					*/
					String user_id=request.getParameter("userName");				
					String password=request.getParameter("password");
					String desig=request.getParameter("des");
					
					String sql="select * from user1 where user_id="+user_id
							+"and password="+password+"and role="+desig;
					String driverName = "oracle.jdbc.driver.OracleDriver";
					Connection conn;
					try {
						conn = DriverManager.getConnection(
						           "jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg611","training611");
						 Statement st=conn.createStatement();
						 int i=st.executeUpdate(sql);
						 if(i==1)
						 {
							 System.out.println("sucess");
						 }
						 else
						 {
							 System.out.println("fail");
						 }
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					 
					
			  /*// int updateCount = bookService.addBookService(bookId, title, price);
					
					System.out.println("inserted "+updateCount+" record   Success");
					
					if (updateCount==1) {
						rd = request.getRequestDispatcher("/success.jsp");
						
					} else {
						rd = request.getRequestDispatcher("/error.jsp");
					}
					rd.forward(request, response);
				}*/
					

}}
