package com.cg.junit;

public class Junit1 {
	
	
	String concat(String s1,String s2)
	{
		return s1+s2;		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public int add(int a, int b) {
		// TODO Auto-generated method stub
		return a+b;
	}
	

}
