package com.cg.junit;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ConcatTest {

	@Test
	public void testConcat()
	{
		Junit1 obj=new Junit1();	
		String res=obj.concat("hello", " world");
		assertEquals("hello world",res);
	}
}
