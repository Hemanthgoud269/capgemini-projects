package com.cg.junit;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AddTest {

	@Test
	public void testAdd() {
			Junit1 obj=new Junit1();	
			int result=obj.add(100, 200);		
			assertEquals(300,result);
			//fail("Not yet implemented");
			
		}

}
