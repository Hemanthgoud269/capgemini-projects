package com.cg.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestPerson {

	@Test
	void testGetFullName() {
		System.out.println("from TestPerson1");
		Person per=new Person("Robert","King");
		assertEquals("Robert King",per.getFullName());
		
		
		//fail("Not yet implemented");
	}
	@Test
	void testNullsInName() 
	{
		System.out.println("from TestPerson1");
		Person per1=new Person(null,"King");
		assertNotNull("full name null",per1.getFullName());
		assertNotNull("first name null",per1.getFirstname());
		
	}
	@Test
	void testGetFirstName() 
	{
		Person p=new Person("Robert","King");
		assertEquals(p.getFirstname(),"Robert");
		
	}
	@Test
	void testGetLastName() 
	{
		Person p=new Person("Robert","King");
		assertEquals(p.getLastname(),"King");
		
	}
	

}
