
import java.sql.*;
public class Jdbcodbc {
	public static void main(String[] args) throws Exception {
  Connection c=null;
  Statement st=null;
  ResultSet rs=null;
  try
  {
	  Class.forName("oracle.jdbc.OracleDriver");
  }
  catch(ClassNotFoundException e)
  {
	  System.out.println(e);
  }
  try
  {
  c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg611","training611");
  System.out.println("connected");
  st=c.createStatement();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  rs=st.executeQuery("select eno,ename,sal from emp3");
  while(rs.next())
  {
	  System.out.println(rs.getInt("eno")+" "+rs.getString(2)+" "+rs.getInt("sal"));
  }
  }
  catch(SQLException se)
  {
	  System.out.println(se);
  }
  finally
  {
	  if(c!=null)
		  try
	  {
	  		  c.close();
	  }
	  catch(SQLException e2)
	  {
		 e2.printStackTrace();
	  }
	  if(st!=null)
		  try
		  {
		  		  st.close();
		  }
		  catch(SQLException e3)
		  {
			 e3.printStackTrace();
		  }
	  if(rs!=null)
		  try
		  {
		  		  rs.close();
		  }
		  catch(SQLException e4)
		  {
			 e4.printStackTrace();
		  }
  }
	}
}