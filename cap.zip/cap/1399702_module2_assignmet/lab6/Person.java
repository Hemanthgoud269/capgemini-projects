package lab6;
import java.util.*;
class Fullexception extends Exception
{public String toString() {
	return"age cannot be less than 15";
}
}
public class Person {
	private String fname;

	private String lname;
	private char gender;
	public Person() {
		fname="FNAME";
		lname="LNMAE";
		gender='N';		
	}
	Person(String fn,String ln, char gn)
	{
		fname=fn;
				lname=ln;
				gender=gn;
	}
 
	public void setFname(String fname) {
		this.fname = fname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getFname() {
		return fname;
	}
	public String getLname() {
		return lname;
	}
	public char getGender() {
		return gender;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p=new Person();
		System.out.println("enter details");
		Scanner sc=new Scanner(System.in);
		String s,s2;
		try
		{
			System.out.println("enter firstname");
			s=sc.next();
			if(s.length()==0)
			{
				throw new Fullexception();
				
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
