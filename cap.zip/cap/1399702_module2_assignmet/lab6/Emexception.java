package lab6;

import java.util.Scanner;

class Employeeexception extends Exception {

	@Override
	public String toString() {
		return "exception";
	}
	 
 }
 public class Emexception
 {private float salary;
 
	

	public void setSalary(float salary) {
	this.salary = salary;
}



	public float getSalary() {
	return salary;
}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		float salary;
		try
		{
		System.out.println("enter slary of employee");
		salary=sc.nextFloat();
		if(salary<3000)
		{
			throw new Employeeexception();
			
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}

		
		
	}

}
