package lab6;
import java.util.Scanner;

import lab4.*;
class Ageexception extends Exception
{public String toString() {
	return"age cannot be less than 15";
}
}
public class Person1 extends Account {
	private String name;
	private int age;
	

	public String getName() {
		return name;
	}


	public int getAge() {
		return age;
	}


	public void setName(String name) {
		this.name = name;
	}


	public void setAge(int age) {
		this.age = age;
	}


	@Override
	public String toString() {
		return "name=" + name + ", balance=" + getBalance() ;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int acc=100;
		Person1 p=new Person1();
		Scanner sc=new Scanner(System.in);
		int age;
		try
		{
			System.out.println("enter age");
			age=sc.nextInt();
			if(age<=15)
			{
				throw new Ageexception();
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		

	}

}

