package lab4;

public class Account {
	private long ano;
	private double balance;
	
	public double getBalance()
	{
		return balance;
	}
	public long getano()
	{
		return ano;
	}
	public void setAno(long ano) {
		this.ano = ano;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public void deposit(double money)
	{
		balance=balance+money;
		System.out.println("balance is :"+ balance);
		
	}
	public void withdraw(double money)
	{
		balance=balance-money;
		System.out.println("balance is"+balance);
	}
	public String toString()
	{
		return "balance="+balance;
	}

}
