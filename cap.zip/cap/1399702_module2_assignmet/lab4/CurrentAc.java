package lab4;

public class CurrentAc extends Account{
	private int limit;
	Account obj=new Account();
	public void Withdraw(double money)
	{
		
			double bal=obj.getBalance();;
			boolean b;
			b=(bal<limit)?true:false;
			System.out.println(b);
	}

}
