package lab4;

public class SbAccount extends Account{
	public final int minb=500;
	public void withdraw(double money)
	{
		double balance;
		Account obj=new Account();
		double a=obj.getBalance();
		if(a<minb)
			System.out.println("cannot withdraw");
		else
		{
			balance=obj.getBalance()-money;
			System.out.println("balance is "+ balance);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		

	}

}
