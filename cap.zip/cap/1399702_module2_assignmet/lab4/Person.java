package lab4;

public class Person extends Account{
	
	private String name;
	private float age;
	

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public float getAge() {
		return age;
	}


	public void setAge(float age) {
		this.age = age;
	}


	@Override
	public String toString() {
		return "Person name=" + name + ", age=" + age ;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int acc=100;
		Person sam=new Person();
		Person tom=new Person();
		sam.setName("sam");
		sam.setBalance(2000);
		sam.setAno(acc++);
		tom.setName("tom");
		tom.setAno(acc++);
		tom.setBalance(3000);
		
		sam.deposit(2000);
		tom.deposit(2000);
		
		sam.getBalance();
		tom.getBalance();
		
		System.out.println(sam);
		System.out.println(tom);

	}

}
