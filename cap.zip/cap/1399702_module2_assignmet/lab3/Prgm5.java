package lab3;

import java.util.Scanner;

public class Prgm5 {
	public static void wdate(int x,int y)
	
	{
		System.out.println("Expiry date is"+x+"/"+(y+1));
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter year and month of the purchase");
		 Scanner o=new Scanner(System.in);
		 int x,y;
		 x=o.nextInt();
		 y=o.nextInt();
		 Prgm5.wdate(x, y);
		 
		

	}
	

}
