package lab3;
import java.util.*;
public class PositiveString {
static boolean operation(String s)
{
	int n=s.length();
	char[] ch=s.toCharArray();
	Arrays.sort(ch);
	String str=String.valueOf(ch);
	int a=0;
	for(int i=0;i<n;i++)
	
		if(str.equals(s))
		{
			a=1;
			
		}
		if(a==1)
			return true;
		else
			return false;
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("enter string");
		String s=sc.next();
		PositiveString ob=new PositiveString();
		System.out.println(ob.operation(s));
	}

}
