package lab3;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.Scanner;

public class prgm3 {
	public void dmy(int year,Month month,int date)
	{
		LocalDate ip=LocalDate.of(year, month, date);
		LocalDate today=LocalDate.now();
		int a,b,c;
		Period age=Period.between(ip,today);
		a=age.getDays();
		b=age.getMonths();
		c=age.getYears();
		System.out.println("days"+a);
		System.out.println("months"+b);
		System.out.println("year"+c);		
	}
	public static void main(String[] args)
	{
		prgm3 obj=new prgm3();
		Scanner obj1=new Scanner(System.in);
	     System.out.println("enter date");
	     System.out.println("enter day");
	     int x,z;
	     Month y;
	     x=obj1.nextInt();
	     System.out.println("enter year");
	     z=obj1.nextInt();
	     y=Month.MAY;
	     obj.dmy(x, y, z);
	} 

}
