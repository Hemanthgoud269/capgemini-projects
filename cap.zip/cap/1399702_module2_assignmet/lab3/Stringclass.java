package lab3;

import java.util.Scanner;

public class Stringclass {
	private String s;
	public void input(String s1,int a)
	{
		switch(a)
		{
		case 1:
			System.out.println(s1+s1);
	        break;
		case 2:
			StringBuilder sb=new StringBuilder(s1);
			for(int i=0;i<sb.length();i++)
			{
				if(i%2==0)
					sb.setCharAt(i, '#');
				
			}
			System.out.println(sb);
			break;
			case 3:
				StringBuilder sb1=new StringBuilder();
				char[] arr=sb1.toString().toCharArray();
				for(char ch:arr)
				{
					if(sb1.indexOf(String.valueOf(ch))==1)
						continue;
					else
						sb1.append(ch);
					
				}
				System.out.println(sb1.toString());
				break;
			case 4:
			for(int i=0;i<s1.length()-1;i++)
			{
				char ch=s1.charAt(i);
				if(i%2==0)
					System.out.println(Character.toUpperCase(ch));
				else
					System.out.println(Character.toLowerCase(ch));
			}
		}
	}

	public static void main(String args[])
	{
		Stringclass obj=new Stringclass();
		Scanner obj1=new Scanner(System.in);
		System.out.println("enter the string");
		String s;
		s=obj1.next();
		System.out.println("1.Add String Toself\n2.Replace odd positions with #\n3.Remove duplicate characters in string\n4.Cgange odd characters to upper case");
		int x;
		x=obj1.nextInt();
		obj.input(s,x);
		
		
	}

}
