package lab3;

import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;

public class Prgm6 {
	public static void dz(String s) throws ParseException
	{
		DateFormat df=new SimpleDateFormat("yyyy-Mm-dd HH:mm:ss");
		Date date=(Date) df.parse(s);
		System.out.println(date);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date date=new Date();
		System.out.println("enter timezone id");
		String s=date.next;
		ZoneId.dataZone(s);

	}
	

}
