/**
 * 
 */
package com.cg.assignment.bean;

/**
 * @author KSURESHK
 *
 */
public class PersonDetails {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
		System.out.println("Person Details:\n");
	
		System.out.println("________________\n");
	
		System.out.println("Frist Name: Divya\n");
		System.out.println("Last Name: Bharathi\n");
		System.out.println("Gender: F\n");
		System.out.println("Age: 20\n");
		System.out.println("Weight: 85.55\n");
		
		
	}

}
