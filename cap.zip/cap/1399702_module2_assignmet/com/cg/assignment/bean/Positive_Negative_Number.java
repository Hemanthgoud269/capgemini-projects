package com.cg.assignment.bean;

import java.util.Scanner;

public class Positive_Negative_Number {

	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number");
		int a=sc.nextInt();
		if(a<0)
			System.out.println("Negative Number");
		else
			System.out.println("Positive Number");
		sc.close();
	}
}
