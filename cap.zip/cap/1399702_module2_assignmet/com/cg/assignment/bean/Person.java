/**
 * 
 */
package com.cg.assignment.bean;

/**
 * @author KSURESHK
 *
 */
public class Person{

	/**
	 * @param args
	 */
	String firstname,lastname;
	char gender;
	String phonenumber;
	
	public Person()
	{
		System.out.println("default constructor is used");
	}
	
	public Person(String firstname, String lastname, char gender,String phonenumber) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.phonenumber=phonenumber;
	}
	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "firstname=" + firstname + "\nlastname=" + lastname + "\ngender=" + gender+" \nphonenumber:" + phonenumber;
	}
	
	
	
	

}
