package com.cg.assignment.bean;

public class PersonMain  {
	
	public static void main(String args[])
	{
		Person pc=new Person("Suresh","Krishna",'M',"8074152456");
		System.out.println(pc);
		
		
	}

}
