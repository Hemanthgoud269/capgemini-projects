package com.cg.eis.p1;
import java.util.*;
import com.cg.eis.bean.*;
import com.cg.eis.service.*;

public class Input extends Employee implements EmployeeService{
	
	public void servicesoffred(int c)
	{
		int x=0;
		String y="NULL",a="NULl",b="NULL";
		long z=0;
		switch(c)
		{
		case 1:
			Input obInput=new Input();
			Scanner sc=new Scanner(System.in);
			System.out.println("enter user id ");
			x=sc.nextInt();
			System.out.println("enter user name");
			y=sc.next();
			System.out.println("enter user salary");
			z=sc.nextInt();
			System.out.println("enter user designation");
			a=sc.next();
			System.out.println("enter insurance scheme");
			b=sc.next();
			break;
		case 2:
			System.out.println(b);
		case 3:
			System.out.println("user id"+x);
			System.out.println("user name"+y);
			System.out.println("user salary"+z);
			System.out.println("user designation"+a);
			System.out.println("insurance scheme"+b);
			break;
								
		}
		
	
	}
	public static void main(String args[])
	{
		Input ob=new Input();
		Scanner sc=new Scanner(System.in);
		System.out.println("1.get employee details from the user"+"\n2.Find the insurance scheme"+"\n3.display details");
		int ch=sc.nextInt();
		ob.servicesoffred(ch);
	}
	
	public void servicesoffered() {
		
		
	}

}
