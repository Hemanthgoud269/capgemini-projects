package com.cg.eis.service;

public interface EmployeeService {
public void servicesoffered();
}
