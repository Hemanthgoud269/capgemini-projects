package com.cg.eis.bean;

public class Employee {
	private int id;
	private String name;
	private long salary;
	private String design;
	private String inschema;
	
	public Employee()
	{
		id=0;
		name="NULL";
		salary=0;
		design="NULL";
		inschema="NULL";
	}
	public Employee(int empid,String name,long salary,String design,String inschema)
	{
		this.id=id;
		this.design=design;
		this.salary=salary;
		this.inschema=inschema;
		
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}
	public void setDesign(String design) {
		this.design = design;
	}
	public void setInschema(String inschema) {
		this.inschema = inschema;
	}
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public long getSalary() {
		return salary;
	}
	public String getDesign() {
		return design;
	}
	public String getInschema() {
		return inschema;
	}


}
