package com.ram;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ClientStudent {
	
	public static void main(String args[])
	{
		Configuration cfg=new Configuration();
		cfg.configure();
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		Student s1=new Student();
		s1.setSno(91);
		s1.setName("suresh");
		s1.setEmail("suresh@gmail.com");
		s1.setMobile(1234569874);
		session.save(s1);
		tx.commit();
		session.close();		
	}

}
