import java.sql.Connection;
import java.sql.DriverManager;

public class Conn {
	static Connection c;
	public static Connection getCon() throws Exception{
	try {
	Class.forName("oracle.jdbc.driver.OracleDriver");
	c = DriverManager.getConnection(
	        "jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg611","training611");

}
	catch(Exception e) {
		System.out.println(e);
	}
	return c;
}

}